# ojs-plugin-lens-bits

This plugin employs an enhanced Version of the Lens Viewer, which was developed for HeiUP,
and can handle a lot of additional JATS- and DARTS-Tags like
enhance tables, section metadata,  Abstracts etc.

* Enhanced Len Viewer original: https://github.com/withanage/UBHD-Lens

## installation

* `git clone https://github.com/paflov/ojs-plugin-lens-bits.git plugins/generic/lensGalleyBits`

## Note

* tested with OJS 3.2.0.0
* please disable the normal Lens-Plugin
